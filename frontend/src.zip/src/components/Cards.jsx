import db from "/src/db/db.json"
import "/src/style.css"

const partners = db.db.partners

export function Cards({ partners = [] }){
    return(
        <div className="cards cards-restaurants">
            {partners.map(partner => (
                <a key={partner.id || partner.name} href="restaurant.html" className="card card-restaurant">
                    <img src={partner.image} alt={partner.name} className="card-image" />
                    <div className="card-text">
                        <div className="card-heading">
                            <h3 className="card-title">{partner.name}</h3>
                            <span className="card-tag tag">{partner.time_of_delivery} мин</span>
                        </div>
                        
                        <div className="card-info">
                            <div className="rating">
                                {partner.stars}
                            </div>
                            <div className="price">От {partner.price}₽</div>
                            <div className="category">{partner.kitchen}</div>
                        </div>
                    </div>
                </a>
            ))}
        </div>
    )
}